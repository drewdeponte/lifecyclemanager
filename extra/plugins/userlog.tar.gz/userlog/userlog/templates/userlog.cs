<?cs include "header.cs" ?>
<?cs include "macros.cs" ?>

<?cs each:csglink = changeset_links ?>
    <?cs var:csglink ?><br/>
<?cs /each ?>

<hr/>

<?cs each:changeset = changesets ?>
    Revision <?cs var:changeset[0] ?> @ <?cs var:changeset[1] ?><br/>
    <?cs var:changeset[2] ?>
    <?cs each:change = changeset[3] ?>
      <?cs var:change[0] ?>
      <?cs if:change[1] ?>
        <pre class="diff">
        <?cs var:change[1] ?>
        </pre>
      <?cs else ?>
        <br/>
      <?cs /if ?>
    <?cs /each ?>
    <hr/>
<?cs /each ?>

<?cs include "footer.cs" ?>
